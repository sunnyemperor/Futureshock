def auto_create_gumroad_products():
    print("📦 Création automatique de produits sur Gumroad...")