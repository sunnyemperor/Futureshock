def fetch_google_trends():
    print("🔍 Connexion à Google Trends... Extraction des requêtes populaires.")