def monitor_stripe_gumroad():
    print("💳 Suivi des revenus Stripe + Gumroad actif.")