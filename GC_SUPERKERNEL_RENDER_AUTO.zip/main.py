from gc_notify_mindstream import notify_gc_sun
from gc_modules.gc_core_engine import start_gc_core_engine

if __name__ == "__main__":
    start_gc_core_engine()
notify_gc_sun()
